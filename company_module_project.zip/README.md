# Company Registration & Verification Module (Minimal Backend)

## What this package contains
- Node.js + Express backend skeleton
- PostgreSQL connection (pg)
- Auth endpoints: register, login (bcrypt + JWT)
- Company profile endpoints: create, get, update (JWT protected)
- SQL schema file `company_db.sql`
- `.env.example` showing env variables to set

This is a minimal **backend-only** deliverable so you can run APIs locally or on Replit/any cloud host.

## Quick Start (Local)
1. Install Node.js (v18+ recommended).
2. Create a PostgreSQL database and import `company_db.sql` or use a hosted Postgres (Neon/Supabase).
   - Example local import:
     ```
     createdb company_module
     psql -U postgres -d company_module -f company_db.sql
     ```
3. Copy `.env.example` to `.env` and fill values.
4. Install dependencies:
   ```
   npm install
   ```
5. Start server:
   ```
   npm run dev
   ```
6. Test health:
   ```
   GET http://localhost:5000/api/health
   ```

## Endpoints
- `POST /api/auth/register`  Register user
  - body: { email, password, full_name, gender, mobile_no }
- `POST /api/auth/login`     Login
  - body: { email, password }  -> returns { token, user }
- `GET /api/company/profile` Get company profile (protected)
- `POST /api/company/register` Create company profile (protected)
- `PUT /api/company/profile`  Update company profile (protected)

## Notes
- This minimal implementation does **not** include Firebase or Cloudinary integrations.
  Those are left as placeholders in the code and comments, with instructions in README.
- You can run this on Replit + Neon by setting `DATABASE_URL` to your Neon Postgres connection string.
