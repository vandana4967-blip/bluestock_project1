const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // If using some hosted PG providers with self-signed certs, you may need:
  // ssl: { rejectUnauthorized: false }
});

pool.on('connect', () => console.log('✅ Connected to PostgreSQL'));
pool.on('error', (err) => console.error('Postgres pool error', err));

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool
};
