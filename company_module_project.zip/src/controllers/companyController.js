const db = require('../services/db');
const sanitizeHtml = require('sanitize-html');

const createCompany = async (req, res) => {
  try {
    const { company_name, address, city, state, country, postal_code, website, industry, founded_date, description, social_links } = req.body;
    const ownerId = req.user.userId;

    // basic sanitize
    const name = sanitizeHtml(company_name || '');
    // check if already exists for owner
    const exists = await db.query('SELECT id FROM company_profile WHERE owner_id=$1', [ownerId]);
    if (exists.rows.length) return res.status(400).json({ message: 'Company profile already exists' });

    const result = await db.query(
      `INSERT INTO company_profile (owner_id, company_name, address, city, state, country, postal_code, website, industry, founded_date, description, social_links)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [ownerId, name, address, city, state, country, postal_code, website, industry, founded_date || null, description, social_links ? JSON.stringify(social_links) : null]
    );
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

const getProfile = async (req, res) => {
  try {
    const ownerId = req.user.userId;
    const result = await db.query('SELECT * FROM company_profile WHERE owner_id=$1', [ownerId]);
    if (!result.rows.length) return res.status(404).json({ message: 'No company profile found' });
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

const updateProfile = async (req, res) => {
  try {
    const ownerId = req.user.userId;
    const fields = req.body;
    // build dynamic update
    const allowed = ['company_name','address','city','state','country','postal_code','website','industry','founded_date','description','social_links','logo_url','banner_url'];
    const sets = [];
    const values = [];
    let idx = 1;
    for (const k of allowed) {
      if (fields[k] !== undefined) {
        sets.push(`${k}=$${idx}`);
        values.push(k === 'social_links' ? JSON.stringify(fields[k]) : fields[k]);
        idx++;
      }
    }
    if (!sets.length) return res.status(400).json({ message: 'No valid fields to update' });
    values.push(ownerId);
    const sql = `UPDATE company_profile SET ${sets.join(', ')} , updated_at = CURRENT_TIMESTAMP WHERE owner_id=$${idx} RETURNING *`;
    const result = await db.query(sql, values);
    return res.json({ success: true, data: result.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { createCompany, getProfile, updateProfile };
