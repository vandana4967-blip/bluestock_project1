const db = require('../services/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const sanitizeHtml = require('sanitize-html');

const register = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password, full_name, gender, mobile_no } = req.body;
    // sanitize
    const name = sanitizeHtml(full_name);
    const sanitizedEmail = sanitizeHtml(email);

    // check exists
    const exists = await db.query('SELECT id FROM users WHERE email=$1', [sanitizedEmail]);
    if (exists.rows.length) return res.status(400).json({ message: 'Email already registered' });

    const hashed = await bcrypt.hash(password, 10);
    const result = await db.query(
      `INSERT INTO users (email, password, full_name, gender, mobile_no, signup_type)
       VALUES ($1,$2,$3,$4,$5,$6) RETURNING id, email, full_name, gender, mobile_no, is_email_verified, is_mobile_verified`,
      [sanitizedEmail, hashed, name, gender || 'o', mobile_no || '', 'e']
    );

    return res.json({ success: true, message: 'User registered', data: result.rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

const login = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password } = req.body;
    const sanitizedEmail = sanitizeHtml(email);
    const userRes = await db.query('SELECT * FROM users WHERE email=$1', [sanitizedEmail]);
    if (!userRes.rows.length) return res.status(400).json({ message: 'Invalid credentials' });

    const user = userRes.rows[0];
    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ message: 'Invalid credentials' });

    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET || 'devsecret', { expiresIn: '90d' });
    // remove password before returning
    delete user.password;
    return res.json({ success: true, token, user });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { register, login };
